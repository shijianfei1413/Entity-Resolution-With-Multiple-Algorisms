Here is the url of our recorded presentation:
https://recordings.rna1.blindsidenetworks.com/columbia/a26cc0165985ea0088fde7f22687c67f0fd18a5e-1714084380734/capture/