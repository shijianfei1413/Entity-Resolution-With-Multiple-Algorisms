import pandas as pd
import difflib

def data_preparation(left, right):
    
    left['postal_code'] = left['postal_code'].astype(str)
    right['zip_code'] = right['zip_code'].astype(str)
    
    left['postal_code'] = left['postal_code'].str[:5]
    right['zip_code'] = right['zip_code'].str[:5]
    
    left['combined_address'] = left['address'] + ' ' + left['city'] + ' ' + left['state'] + ' ' + left['postal_code']
    right['combined_address'] = right['address'] + ' ' + right['city'] + ' ' + right['state'] + ' ' + right['zip_code']
    
    for col in left.columns:
        left[col] = left[col].apply(lambda x: x.lower() if type(x) == str else x)
    for col in right.columns:
        right[col] = right[col].apply(lambda x: x.lower() if type(x) == str else x)
    
    return left, right


def find_matches(df1, df2, key1_primary, key2_primary, key1_secondary, key2_secondary, threshold=0.8):
    
    matches = []
    
    for i, row1 in df1.iterrows():
        best_score = threshold
        best_match = None
        for j, row2 in df2.iterrows():
            primary1 = str(row1[key1_primary]) if pd.notna(row1[key1_primary]) else ''
            primary2 = str(row2[key2_primary]) if pd.notna(row2[key2_primary]) else ''
            score = difflib.SequenceMatcher(None, primary1, primary2).ratio()
            if score > best_score:
                best_score = score
                best_match = (row1['entity_id'], row2['business_id'], score)
        if best_match:
            matches.append(best_match)
            
        else:
            secondary1 = str(row1[key1_secondary]) if pd.notna(row1[key1_secondary]) else ''
            secondary2 = str(row2[key2_secondary]) if pd.notna(row2[key2_secondary]) else ''
            score = difflib.SequenceMatcher(None, secondary1, secondary2).ratio()
            if score > best_score:
                best_score = score
                best_match = (row1['entity_id'], row2['business_id'], score)
            if best_match:
                matches.append(best_match)
    return matches


def match_all(df1, df2, city_list):
    
    all_matches = []
    
    for city in city_list:
        
        left_data = df1[df1['city'] == city]
        right_data = df2[df2['city'] == city]
        
        refined_matches = find_matches(left_data, right_data, 'name', 'name', 'combined_address', 'combined_address')
        all_matches.append(refined_matches)
        
    return all_matches