#!/usr/bin/env python
# coding: utf-8

# In[14]:


import pandas as pd

# Load the datasets
left_dataset_path = 'left_dataset.csv'
right_dataset_path = 'right_dataset.csv'

left_df = pd.read_csv(left_dataset_path)
right_df = pd.read_csv(right_dataset_path)


# In[15]:


# delete the columns of "size", "categroy"
left_df.drop(columns=['categories'], inplace=True)
right_df.drop(columns=['size'], inplace=True)


# In[16]:


# Change postal_code to zip_code
left_df['postal_code'] = left_df['postal_code'].apply(lambda x: str(int(x)) if pd.notna(x) else '')

left_df.rename(columns={'postal_code': 'zip_code'}, inplace=True)

# For the right dataset, split the 'zip_code' on the hyphen and take the first part
right_df['zip_code'] = right_df['zip_code'].apply(lambda x: x.split('-')[0].strip())


# In[17]:


# Trim the zip_code to the first five digits in both datasets, handling None values
left_df['zip_code'] = left_df['zip_code'].apply(lambda x: x[:5] if x and len(x) >= 5 else x)
right_df['zip_code'] = right_df['zip_code'].apply(lambda x: x[:5] if x and len(x) >= 5 else x)

left_df['zip_code'].head(), right_df['zip_code'].head()


# In[18]:


for column in left_df.columns:
    if pd.api.types.is_numeric_dtype(left_df[column]):
        left_df[column] = left_df[column].astype(str)

for column in right_df.columns:
    if pd.api.types.is_numeric_dtype(right_df[column]):
        right_df[column] = right_df[column].astype(str)



# In[19]:


#create block_key
left_df['block_key'] = (left_df['zip_code'].str[:3] + 
                        left_df['state'] + 
                        left_df['name'].str[0].str.upper())

right_df['block_key'] = (right_df['zip_code'].str[:3] + 
                         right_df['state'] + 
                         right_df['name'].str[0].str.upper())

# Ensure the new columns are strings and handle any potential missing values
left_df['block_key'] = left_df['block_key'].astype(str)
right_df['block_key'] = right_df['block_key'].astype(str)


# In[20]:


left_df


# In[21]:


right_df


# In[22]:


import pandas as pd
from unidecode import unidecode
import re

def normalize_text(column):
    column = column.astype(str)
    column = column.str.lower()
    column = column.apply(unidecode)
    column = column.str.replace(r'[^\w\s]', '', regex=True)
    return column


# Normalize business names
left_df['name'] = normalize_text(left_df['name'])
right_df['name'] = normalize_text(right_df['name'])

# Normalize addresses
left_df['address'] = normalize_text(left_df['address'])
right_df['address'] = normalize_text(right_df['address'])


# In[26]:


# remove the white space, and Standardize the address 

import pandas as pd
import re

def standardize_address(address):
    # Convert to string in case there are any non-string types
    address = str(address)
    # Remove any leading/trailing whitespace
    address = address.strip()
    # Replace common street suffix abbreviations with a standard
    street_suffixes = {
        'st.': 'Street', 'rd.': 'Road', 'ave.': 'Avenue',
        'dr.': 'Drive', 'ln.': 'Lane', 'blvd.': 'Boulevard'
    }
    for suffix in street_suffixes:
        address = re.sub(r'\b' + suffix + r'\b', street_suffixes[suffix], address, flags=re.IGNORECASE)
    # Standardize directional prefixes/suffixes
    directions = {
        'n ': 'North ', 's ': 'South ', 'e ': 'East ', 'w ': 'West ',
        'ne ': 'Northeast ', 'nw ': 'Northwest ', 'se ': 'Southeast ', 'sw ': 'Southwest '
    }
    for direction in directions:
        address = re.sub(r'\b' + direction, directions[direction], address, flags=re.IGNORECASE)
    # Standardize suite numbers
    address = re.sub(r'\bste\.? ', 'Suite ', address, flags=re.IGNORECASE)
    address = re.sub(r'\bapt\.? ', 'Apartment ', address, flags=re.IGNORECASE)
    # Remove all other special characters except for the hyphen and forward slash
    address = re.sub(r'[^\w\s/-]', '', address)
    # Replace multiple spaces with a single space
    address = re.sub(r'\s+', ' ', address)
    return address

# Apply the function to the address column of your DataFrames
left_df['address'] = left_df['address'].apply(standardize_address)
right_df['address'] = right_df['address'].apply(standardize_address)


# In[27]:


# Apply title case to the 'city' column of your DataFrames
left_df['city'] = left_df['city'].str.title()
right_df['city'] = right_df['city'].str.title()


# In[28]:


# add combine column

left_df['zip_code'] = left_df['zip_code'].astype(str)
right_df['zip_code'] = right_df['zip_code'].astype(str)

left_df['combined'] = left_df[['name', 'address', 'zip_code']].agg(' '.join, axis=1)
right_df['combined'] = right_df[['name', 'address', 'zip_code']].agg(' '.join, axis=1)


# In[29]:


left_df


# In[39]:


import pandas as pd
import recordlinkage
from recordlinkage.index import Block

# Assuming previous steps are the same as provided (data loading, cleaning, and normalization)

# Using recordlinkage package

# Create an indexer object and use blocking on 'block_key'
indexer = Block('block_key')
pairs = indexer.index(left_df, right_df)

# Initialize the comparison object
compare = recordlinkage.Compare()

# Add comparison criteria. Here compare the 'combined' column using the Jaro-Winkler method.
compare.string('combined', 'combined', method='jarowinkler', threshold=0.85, label='combined_score')

# Compute the comparison vector
features = compare.compute(pairs, left_df, right_df)

# Filter matches based on the score threshold
matches = features[features['combined_score'] > 0.85]

# Create a DataFrame from the matches with only necessary columns
results = pd.DataFrame({
    'left_id': matches.index.get_level_values(0),
    'right_id': matches.index.get_level_values(1),
    'score': matches['combined_score']
})

# Display or save the results
print(results)


# In[45]:


import pandas as pd
import recordlinkage
from recordlinkage.index import Block

# Assuming previous steps are the same as provided (data loading, cleaning, and normalization)

# Using recordlinkage package

# Create an indexer object and use blocking on 'block_key'
indexer = Block('block_key')
pairs = indexer.index(left_df, right_df)

# Initialize the comparison object
compare = recordlinkage.Compare()

# Add comparison criteria. Here compare the 'combined' column using the Jaro-Winkler method.
compare.string('combined', 'combined', method='jarowinkler', threshold=0.85, label='combined_score')

# Compute the comparison vector
features = compare.compute(pairs, left_df, right_df)

# Filter matches based on the score threshold
matches = features[features['combined_score'] > 0.85]

# Create a DataFrame from the matches with only necessary columns
results = pd.DataFrame({
    'left_id': matches.index.get_level_values(0),
    'right_id': matches.index.get_level_values(1),
    'score': matches['combined_score']
})

# Save the results to a CSV file
results.to_csv('matching_results.csv', index=False)

print("Results have been saved to 'matching_results.csv'")


# In[ ]:




