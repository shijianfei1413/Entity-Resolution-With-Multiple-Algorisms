import os
import pandas as pd

LEFT_DATASET_NAME = "left_dataset.csv"
RIGHT_DATASET_NAME = "right_dataset.csv"

def data_preparation():
    
    current_path = os.path.dirname(__file__)
    path_to_data_dir = os.path.join(current_path, "..", "data")
    left = pd.read_csv(os.path.join(path_to_data_dir, LEFT_DATASET_NAME))
    right = pd.read_csv(os.path.join(path_to_data_dir, RIGHT_DATASET_NAME))
    
    left['postal_code'] = left['postal_code'].astype(str)
    right['zip_code'] = right['zip_code'].astype(str)
    
    left['postal_code'] = left['postal_code'].str[:5]
    right['zip_code'] = right['zip_code'].str[:5]
    
    left['combined_address'] = left['address'] + ' ' + left['city'] + ' ' + left['state'] + ' ' + left['postal_code']
    right['combined_address'] = right['address'] + ' ' + right['city'] + ' ' + right['state'] + ' ' + right['zip_code']
    
    for col in left.columns:
        left[col] = left[col].apply(lambda x: x.lower() if type(x) == str else x)
    for col in right.columns:
        right[col] = right[col].apply(lambda x: x.lower() if type(x) == str else x)
    
    return left, right