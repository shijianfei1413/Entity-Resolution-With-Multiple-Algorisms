#!/usr/bin/env python
# coding: utf-8

# In[1]:


pip install fuzzywuzzy


# In[2]:


from fuzzywuzzy import fuzz
import pandas as pd

left_df = pd.read_csv('/Users/yvonneyue/Downloads/left_dataset.csv')
right_df = pd.read_csv('/Users/yvonneyue/Downloads/right_dataset.csv')


# In[3]:


left_df['full_address'] = left_df.apply(lambda row: f"{row['address']}, {row['postal_code']}", axis=1)
left_df.head()


# In[4]:


right_df['simple_zip_code'] = right_df['zip_code'].str.slice(0, 5)
right_df['simple_zip_code'] = right_df['simple_zip_code'].astype(int)
right_df['full_address'] = right_df.apply(lambda row: f"{row['address']}, {row['zip_code']}", axis=1)
right_df.head()


# In[5]:


def calculate_similarity(left, right):
    left = str(left['name']) + str(left['address'])
    right = str(right['name']) + str(right['address'])
    confidence_score = fuzz.token_sort_ratio(left, right)
    return confidence_score


# In[ ]:





# ### postal_code and zip_code in -19000

# In[6]:


left_df_19000 = left_df[left_df['postal_code'] <= 19000]
right_df_19000 = right_df[right_df['simple_zip_code'] <= 19000]


# In[7]:


len(left_df_19000)


# In[8]:


matches_19000 = []
for index_left, left in left_df_19000.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_19000.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_19000.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[9]:


for match in matches_19000:
    match['confidence_score'] /= 100.0


# In[10]:


#matches_df_FL = pd.DataFrame(matches_FL)
flt_matches_19000 = [match for match in matches_19000 if match['confidence_score'] > 0.8]
flt_matches_19000[:5]


# In[11]:


len(flt_matches_19000)


# ### postal_code and zip_code in 19001-19100

# In[12]:


left_df_19001_19100 = left_df[(left_df['postal_code'] >= 19001) & (left_df['postal_code'] <= 19100)]
right_df_19001_19100 = right_df[(right_df['simple_zip_code'] >= 19001) & (right_df['simple_zip_code'] <= 19100)]


# In[13]:


len(left_df_19001_19100)


# In[14]:


matches_19001_19100 = []
for index_left, left in left_df_19001_19100.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_19001_19100.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_19001_19100.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[15]:


for match in matches_19001_19100:
    match['confidence_score'] /= 100.0


# In[16]:


flt_matches_19001_19100 = [match for match in matches_19001_19100 if match['confidence_score'] > 0.8]
flt_matches_19001_19100[:5]


# In[17]:


len(flt_matches_19001_19100)


# ### postal_code and zip_code in 19101-19140

# In[18]:


left_df_19101_19140 = left_df[(left_df['postal_code'] >= 19100) & (left_df['postal_code'] <= 19140)]
right_df_19101_19140 = right_df[(right_df['simple_zip_code'] >= 19100) & (right_df['simple_zip_code'] <= 19140)]


# In[19]:


len(right_df_19101_19140)


# In[20]:


matches_19101_19140 = []
for index_left, left in left_df_19101_19140.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_19101_19140.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_19101_19140.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[21]:


for match in matches_19101_19140:
    match['confidence_score'] /= 100.0


# In[22]:


flt_matches_19101_19140 = [match for match in matches_19101_19140 if match['confidence_score'] > 0.8]
flt_matches_19101_19140[:5]


# In[23]:


len(flt_matches_19101_19140)


# ### postal_code and zip_code in 19141-19410

# In[24]:


left_df_19141_19410 = left_df[(left_df['postal_code'] >= 19141) & (left_df['postal_code'] <= 19410)]
right_df_19141_19410 = right_df[(right_df['simple_zip_code'] >= 19141) & (right_df['simple_zip_code'] <= 19410)]


# In[25]:


len(right_df_19141_19410)


# In[26]:


matches_19141_19410 = []
for index_left, left in left_df_19141_19410.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_19141_19410.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_19141_19410.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[27]:


for match in matches_19141_19410:
    match['confidence_score'] /= 100.0


# In[28]:


flt_matches_19141_19410 = [match for match in matches_19141_19410 if match['confidence_score'] > 0.8]
flt_matches_19141_19410[:5]


# In[29]:


len(flt_matches_19141_19410)


# ### postal_code and zip_code in 19411-33600

# In[30]:


left_df_19411_33600 = left_df[(left_df['postal_code'] >= 19411) & (left_df['postal_code'] <= 33600)]
right_df_19411_33600 = right_df[(right_df['simple_zip_code'] >= 19411) & (right_df['simple_zip_code'] <= 33600)]


# In[31]:


len(right_df_19411_33600)


# In[32]:


matches_19411_33600 = []
for index_left, left in left_df_19411_33600.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_19411_33600.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_19411_33600.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[33]:


for match in matches_19411_33600:
    match['confidence_score'] /= 100.0


# In[34]:


flt_matches_19411_33600 = [match for match in matches_19411_33600 if match['confidence_score'] > 0.8]
flt_matches_19411_33600[:5]


# In[35]:


len(flt_matches_19411_33600)


# ### postal_code and zip_code in 33601-33640

# In[36]:


left_df_33601_33640 = left_df[(left_df['postal_code'] >= 33601) & (left_df['postal_code'] <= 33640)]
right_df_33601_33640 = right_df[(right_df['simple_zip_code'] >= 33601) & (right_df['simple_zip_code'] <= 33640)]


# In[37]:


len(right_df_33601_33640)


# In[38]:


matches_33601_33640 = []
for index_left, left in left_df_33601_33640.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_33601_33640.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_33601_33640.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[39]:


for match in matches_33601_33640:
    match['confidence_score'] /= 100.0


# In[40]:


flt_matches_33601_33640 = [match for match in matches_33601_33640 if match['confidence_score'] > 0.8]
flt_matches_33601_33640[:5]


# In[41]:


len(flt_matches_33601_33640)


# ### postal_code and zip_code in 33641-34000

# In[42]:


left_df_33641_34000 = left_df[(left_df['postal_code'] >= 33641) & (left_df['postal_code'] <= 34000)]
right_df_33641_34000 = right_df[(right_df['simple_zip_code'] >= 33641) & (right_df['simple_zip_code'] <= 34000)]


# In[43]:


len(right_df_33641_34000)


# In[44]:


matches_33641_34000 = []
for index_left, left in left_df_33641_34000.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_33641_34000.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_33641_34000.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[45]:


for match in matches_33641_34000:
    match['confidence_score'] /= 100.0


# In[46]:


flt_matches_33641_34000 = [match for match in matches_33641_34000 if match['confidence_score'] > 0.8]
flt_matches_33641_34000[:5]


# In[47]:


len(flt_matches_33641_34000)


# ### postal_code and zip_code in 34001-37190

# In[48]:


left_df_34001_37190 = left_df[(left_df['postal_code'] >= 34001) & (left_df['postal_code'] <= 37190)]
right_df_34001_37190 = right_df[(right_df['simple_zip_code'] >= 34001) & (right_df['simple_zip_code'] <= 37190)]


# In[49]:


len(right_df_34001_37190)


# In[50]:


matches_34001_37190 = []
for index_left, left in left_df_34001_37190.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_34001_37190.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_34001_37190.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[51]:


for match in matches_34001_37190:
    match['confidence_score'] /= 100.0


# In[52]:


flt_matches_34001_37190 = [match for match in matches_34001_37190 if match['confidence_score'] > 0.8]
flt_matches_34001_37190[:5]


# In[53]:


len(flt_matches_34001_37190)


# ### postal_code and zip_code in 37191-46190

# In[54]:


left_df_37191_46190 = left_df[(left_df['postal_code'] >= 37191) & (left_df['postal_code'] <= 46190)]
right_df_37191_46190 = right_df[(right_df['simple_zip_code'] >= 37191) & (right_df['simple_zip_code'] <= 46190)]


# In[55]:


len(right_df_37191_46190)


# In[56]:


matches_37191_46190 = []
for index_left, left in left_df_37191_46190.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_37191_46190.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_37191_46190.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[57]:


for match in matches_37191_46190:
    match['confidence_score'] /= 100.0


# In[58]:


flt_matches_37191_46190 = [match for match in matches_37191_46190 if match['confidence_score'] > 0.8]
flt_matches_37191_46190[:5]


# In[59]:


len(flt_matches_37191_46190)


# ### postal_code and zip_code in 46191-63090

# In[60]:


left_df_46191_63090 = left_df[(left_df['postal_code'] >= 46191) & (left_df['postal_code'] <= 63090)]
right_df_46191_63090 = right_df[(right_df['simple_zip_code'] >= 46191) & (right_df['simple_zip_code'] <= 63090)]


# In[61]:


len(right_df_46191_63090)


# In[62]:


matches_46191_63090 = []
for index_left, left in left_df_46191_63090.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_46191_63090.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_46191_63090.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[63]:


for match in matches_46191_63090:
    match['confidence_score'] /= 100.0


# In[64]:


flt_matches_46191_63090 = [match for match in matches_46191_63090 if match['confidence_score'] > 0.8]
flt_matches_46191_63090[:5]


# In[65]:


len(flt_matches_46191_63090)


# ### postal_code and zip_code in 63091-

# In[66]:


left_df_63091 = left_df[left_df['postal_code'] >= 63091]
right_df_63091 = right_df[right_df['simple_zip_code'] >= 63091]


# In[67]:


len(right_df_63091)


# In[68]:


matches_63091 = []
for index_left, left in left_df_63091.iterrows():
    best_match = None
    best_score = 0
    for index_right, right in right_df_63091.iterrows():
        score = calculate_similarity(left, right)
        if score > best_score:
            best_score = score
            best_match = right
    matches_63091.append({'left_dataset': left['entity_id'], 'right_dataset': best_match['business_id'], 'confidence_score': best_score})


# In[69]:


for match in matches_63091:
    match['confidence_score'] /= 100.0


# In[70]:


flt_matches_63091 = [match for match in matches_63091 if match['confidence_score'] > 0.8]
flt_matches_63091[:5]


# In[71]:


len(flt_matches_63091)


# In[ ]:





# In[72]:


len(flt_matches_19000) + len(flt_matches_19001_19100) + len(flt_matches_19101_19140) + len(flt_matches_19141_19410) + len(flt_matches_19411_33600) + len(flt_matches_33601_33640) + len(flt_matches_33641_34000) + len(flt_matches_34001_37190) + len(flt_matches_37191_46190) + len(flt_matches_46191_63090) + len(flt_matches_63091)


# In[ ]:




